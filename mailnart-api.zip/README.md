# MailNArt APIs


# Table of Contents
1. [Payment Services](#Payment)


# Payment Services


### payment/checkout
`{ "items": [{"name": "Art", "priceInCents": 10000, "quantity": 3}] }`