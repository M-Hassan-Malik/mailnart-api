{
    "accountNumber": {
      "value": "510087380"
    },
    "requestedShipment": {
      "shipper": {
        "address": {
          "postalCode": 65247,
          "countryCode": "US"
        }
      },
      "recipient": {
        "address": {
          "postalCode": 75063,
          "countryCode": "US"
        }
      },
      "pickupType": "USE_SCHEDULED_PICKUP",
      "serviceType": "FEDEX_EXPRESS_SAVER",
        "rateRequestType": [
        "LIST",
        "ACCOUNT"
      ],
      "requestedPackageLineItems": [
        {
          "weight": {
            "units": "LB",
            "value": 10
          }
        }
      ]
    }
  }